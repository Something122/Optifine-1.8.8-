package net.minecraft.client;

public class ClientBrandRetriever
{
    public static String getClientModName()
    {
        return "vanilla";
    }
}
